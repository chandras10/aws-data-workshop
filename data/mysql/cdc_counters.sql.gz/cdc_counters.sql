INSERT INTO insert_count_cdc (count) values(0);
INSERT INTO update_count_cdc (count) values(0);
INSERT INTO delete_count_cdc (count) values(0);
